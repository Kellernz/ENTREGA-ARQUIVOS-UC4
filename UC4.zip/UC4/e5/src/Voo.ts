import { Data } from './Data';

export class Voo {
    private id: string;
    private data: Data;
    private assentos: boolean[];

    constructor(id: string, data: Data) {
        this.id = id;
        this.data = data;
        this.assentos = new Array<boolean>(100).fill(false);
    }

    public proximoLivre(): number
    {
        for (let i = 0; i < this.assentos.length; ++i) {
            if (!this.assentos[i]) {
                return i + 1;
            }
        }

        return 0;
    }

    public verifica(vaga: number): boolean { return !(this.assentos[vaga - 1]); }

    public ocupa(vaga: number): boolean
    {
        vaga -= 1;
        if (vaga >= this.assentos.length || vaga < 0 || this.assentos[vaga])
            return false;
        return (this.assentos[vaga] = true);
    }

    public vagas(): number
    {
        let contagemDeVagas = 0;
        for (let i = 0; i < this.assentos.length; ++i) {
            if (this.verifica(i)) {
                contagemDeVagas += 1;
            }
        }

        return contagemDeVagas;
    }

    public getVoo(): string {
        return this.id;
    }

    public getData(): Data {
        return this.data;
    }

    public clone(): Voo {
        return new Voo(this.id, this.data);
    }
};
