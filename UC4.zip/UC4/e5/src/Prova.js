"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Prova = exports.Gabarito = void 0;
var Gabarito = /** @class */ (function () {
    function Gabarito() {
        this.respostas = [];
        this.pesos = [];
    }
    Gabarito.prototype.getRespostas = function () { return this.respostas.join(', '); };
    Gabarito.prototype.addResposta = function (resposta, peso) {
        this.pesos.push(peso);
        this.respostas.push(resposta);
    };
    Gabarito.prototype.delRespostas = function () {
        this.pesos = [];
        this.respostas = [];
    };
    return Gabarito;
}());
exports.Gabarito = Gabarito;
;
var Prova = /** @class */ (function () {
    function Prova(gabarito) {
        this.respostas = [];
        this.gabarito = gabarito;
    }
    Prova.prototype.respostaAluno = function (resposta) {
        this.respostas.push(resposta);
    };
    Prova.prototype.nota = function () {
        var nota = 0;
        for (var i = 0; i < this.respostas.length; i++) {
            if (this.respostas[i] === this.gabarito.respostas[i]) {
                nota += this.gabarito.pesos[i];
            }
        }
        return nota;
    };
    Prova.prototype.acertos = function () {
        var acertos = 0;
        for (var i = 0; i < this.respostas.length; i++) {
            if (this.respostas[i] === this.gabarito.respostas[i]) {
                acertos++;
            }
        }
        return acertos;
    };
    Prova.prototype.maior = function (outra) {
        return this.nota() > outra.nota() ? 1 : 0;
    };
    Prova.prototype.clone = function () {
        var clone = new Prova(this.gabarito);
        clone.respostas = __spreadArray([], this.respostas, true);
        return clone;
    };
    return Prova;
}());
exports.Prova = Prova;
