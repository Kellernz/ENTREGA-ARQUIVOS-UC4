import { Data } from  './Data';

export class Gabarito {
	public respostas: string[] = [];
	public pesos: number[] = [];
	public constructor() {}

	public getRespostas(): string { return this.respostas.join(', '); }

	public addResposta(resposta: string, peso: number): void {
		this.pesos.push(peso);
		this.respostas.push(resposta);
	}

	public delRespostas(): void {
		this.pesos = [];
		this.respostas = [];
	}
};

export class Prova {
	public respostas: string[] = [];
	public gabarito: Gabarito;
	
	constructor(gabarito: Gabarito) {
		this.gabarito = gabarito;	
	}

	public respostaAluno(resposta: string): void {
		this.respostas.push(resposta);
	}

	public nota(): number {
		let nota = 0;
		for (let i = 0; i < this.respostas.length; i++) {
			if (this.respostas[i] === this.gabarito.respostas[i]) {
				nota += this.gabarito.pesos[i];
			}
		}
		return nota;
	}

	public acertos(): number {
		let acertos = 0;
		for (let i = 0; i < this.respostas.length; i++) {
			if (this.respostas[i] === this.gabarito.respostas[i]) {
				acertos++;
			}
		}

		return acertos;
	}

	public maior(outra: Prova): number {
		return this.nota() > outra.nota() ? 1 : 0;
	}
    
	public clone(): Prova {
		const clone = new Prova(this.gabarito);
		clone.respostas = [...this.respostas];
		return clone;
	}
}
