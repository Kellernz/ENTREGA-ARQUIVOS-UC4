"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Voo = void 0;
var Voo = /** @class */ (function () {
    function Voo(id, data) {
        this.id = id;
        this.data = data;
        this.assentos = new Array(100).fill(false);
    }
    Voo.prototype.proximoLivre = function () {
        for (var i = 0; i < this.assentos.length; ++i) {
            if (!this.assentos[i]) {
                return i + 1;
            }
        }
        return 0;
    };
    Voo.prototype.verifica = function (vaga) { return !(this.assentos[vaga - 1]); };
    Voo.prototype.ocupa = function (vaga) {
        vaga -= 1;
        if (vaga >= this.assentos.length || vaga < 0 || this.assentos[vaga])
            return false;
        return (this.assentos[vaga] = true);
    };
    Voo.prototype.vagas = function () {
        var contagemDeVagas = 0;
        for (var i = 0; i < this.assentos.length; ++i) {
            if (this.verifica(i)) {
                contagemDeVagas += 1;
            }
        }
        return contagemDeVagas;
    };
    Voo.prototype.getVoo = function () {
        return this.id;
    };
    Voo.prototype.getData = function () {
        return this.data;
    };
    Voo.prototype.clone = function () {
        return new Voo(this.id, this.data);
    };
    return Voo;
}());
exports.Voo = Voo;
;
