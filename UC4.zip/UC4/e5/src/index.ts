import { Aluno } from './Aluno';
import { Data } from './Data';
import { Voo } from './Voo';
import { Gabarito, Prova } from './Prova';

let aluno = new Aluno(821, "Aluno Sem Nome", 5, 4, 10);

console.log(aluno); 
console.log(aluno.media());
console.log(aluno.final());

let data = new Data(10, 1, 2011);

console.log(data);
console.log(data.getDia());
console.log(data.getMes());
console.log(data.getAno());
console.log(data.compara(new Data(12, 8, 2008)));
console.log(data.isBissexto());

let voo = new Voo("91134", new Data(11, 2, 2024));

console.log(voo);
console.log(voo.ocupa(1));
console.log(voo.verifica(1));
console.log(voo.vagas());
console.log(voo.getData());

let gabarito = new Gabarito();

gabarito.addResposta('a', 1);
gabarito.addResposta('b', 2);
gabarito.addResposta('c', 3);
gabarito.addResposta('d', 4);
gabarito.addResposta('e', 5);

let prova = new Prova(gabarito);

prova.respostaAluno('b');
prova.respostaAluno('c');
prova.respostaAluno('d');
prova.respostaAluno('e');
prova.respostaAluno('a');

console.log(prova);

console.log(prova.acertos());
console.log(prova.nota());
