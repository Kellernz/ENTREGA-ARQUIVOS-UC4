"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Data = void 0;
var Data = /** @class */ (function () {
    function Data(dia, mes, ano) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }
    Data.prototype.compara = function (outra) {
        return (this.ano === outra.getAno() && this.mes === outra.getMes() && this.dia === outra.getDia()) ? 1 : 0;
    };
    Data.prototype.getDia = function () {
        return this.dia;
    };
    Data.prototype.getMes = function () {
        return this.mes;
    };
    Data.prototype.getAno = function () {
        return this.ano;
    };
    Data.prototype.getMesExtenso = function () {
        var meses = [
            'janeiro', 'fevereiro', 'março',
            'abril', 'maio', 'junho',
            'julho', 'agosto', 'setembro',
            'outubro', 'novembro', 'dezembro'
        ];
        return meses[this.mes - 1];
    };
    Data.prototype.isBissexto = function () {
        return (this.ano % 4 === 0 && this.ano % 100 !== 0) || (this.ano % 400 === 0);
    };
    Data.prototype.clone = function () {
        return new Data(this.dia, this.mes, this.ano);
    };
    return Data;
}());
exports.Data = Data;
;
