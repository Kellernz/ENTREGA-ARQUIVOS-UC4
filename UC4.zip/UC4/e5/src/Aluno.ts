import * as rl from 'readline-sync';

export class Aluno {
    matricula: number;
    nome: string;
    notaProva1: number;
    notaProva2: number;
    notaTrabalho: number;

    constructor(matricula: number, nome: string, notaProva1: number, notaProva2: number, notaTrabalho: number) {
        this.matricula = matricula;
	this.nome = nome;
	this.notaProva1 = notaProva1;
	this.notaProva2 = notaProva2;
	this.notaTrabalho = notaTrabalho;
    }

    public setAluno(): void {
        this.matricula = rl.questionInt("Qual o numero da matricula?");
        this.nome = rl.question("Qual o nome do aluno? ");
        this.notaProva1 = rl.questionInt("Qual a nota da primeira prova? ");
        this.notaProva2 = rl.questionInt("Qual a nota da segunda prova? ");
        this.notaTrabalho = rl.questionInt("Qual a nota do trabalho? ");
    }

    public getAluno(): string {
        return `Matrícula: ${this.matricula}\nNome: ${this.nome}\nNota Prova 1: ${this.notaProva1}\nNota Prova 2: ${this.notaProva2}\nNota Trabalho: ${this.notaTrabalho}`;    
    }

    public media(): number {
        return (this.notaProva1 + this.notaProva2) / 2;
    }

    public final(): number {
        return (this.notaProva1 + this.notaProva2 + this.notaTrabalho) / 3;
    }
};
