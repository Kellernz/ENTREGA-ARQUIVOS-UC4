export class Data {
    private dia: number;
    private mes: number;
    private ano: number;

    constructor(dia: number, mes: number, ano: number) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    public compara(outra: Data): number {
        return (this.ano === outra.getAno() && this.mes === outra.getMes() && this.dia === outra.getDia()) ? 1 : 0;
    }

    public getDia(): number {
        return this.dia;
    }

    public getMes(): number {
        return this.mes;
    }

    public getAno(): number {
        return this.ano;
    }
    
    public getMesExtenso(): string {
        const meses = [
		'janeiro', 'fevereiro', 'março',
		'abril', 'maio', 'junho',
		'julho', 'agosto', 'setembro',
		'outubro', 'novembro', 'dezembro'
	];

        return meses[this.mes - 1];
    }

    public isBissexto(): boolean {
        return (this.ano % 4 === 0 && this.ano % 100 !== 0) || (this.ano % 400 === 0);
    }

    public clone(): Data {
        return new Data(this.dia, this.mes, this.ano);
    }
};
