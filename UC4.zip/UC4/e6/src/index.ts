import * as rl from 'readline-sync';

import { contadorMenu } from './menu/Contador'
import { ponto2DMenu } from './menu/Ponto2D'
import { numeroComplexoMenu } from './menu/NumeroComplexo'

function menu(): void {
    console.clear();
    
    let opt = -1;

    while (opt != 0) {
        console.log('Menu');
        console.log('0. Sair');
        console.log('1. Contador');
        console.log('2. Ponto 2D');
        console.log('3. Numero Complexo');

        opt = Number(rl.questionInt('Digite uma das opções acima: '));
        switch (opt) {
            case 0:
                break;
            case 1:
                contadorMenu();
                break;
            case 2:
                ponto2DMenu();
                break;
            case 3:
                numeroComplexoMenu();
                break;
            default:
                console.log('Digite uma opção válida');
                rl.question('Pressione Enter para prosseguir...');
                break;
        }
    }

    console.clear();
}

menu();
