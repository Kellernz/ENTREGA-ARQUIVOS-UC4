import * as rl from 'readline-sync';
import { Contador } from '../Contador';

export function contadorMenu(): void {
    let contador = new Contador();
    let opt: number = -1;
    
    console.clear();

    while (opt != 0) {
        console.log('Menu contador');
        console.log('0. Sair');
        console.log('1. Incrementar');
        console.log('2. Zerar');

        opt = rl.questionInt("Escolha uma opcao: "); 

        switch (opt) {
            case 0:
                break;
            case 1:
                contador.incrementar();
                console.log(contador.valor());
                break;
            case 2:
                contador.zerar();
                console.log(contador.valor());
                break;
	    default:
		console.log('Por favor, digite uma das opções acima.');
		break;
        }
            
        rl.question("Aperte enter para avancar");
        console.clear();
    }
}
