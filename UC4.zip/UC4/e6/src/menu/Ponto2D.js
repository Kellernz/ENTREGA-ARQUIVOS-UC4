"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ponto2DMenu = void 0;
var rl = require("readline-sync");
var Ponto2D_1 = require("../Ponto2D");
function ponto2DMenu() {
    var ponto = new Ponto2D_1.Ponto2D();
    var tmp = new Ponto2D_1.Ponto2D();
    var opt = -1;
    while (opt !== 0) {
        console.clear();
        console.log('Menu Ponto 2D');
        console.log('0. Sair');
        console.log('1. Mostrar x');
        console.log('2. Mostrar y');
        console.log('3. Definir x');
        console.log('4. Definir y');
        console.log('5. Comparar com outro');
        console.log('6. Mostrar distância para outro');
        console.log('7. Clonar ponto');
        console.log('8. Mostrar valor');
        opt = rl.questionInt("Escolha uma opção: ");
        switch (opt) {
            case 0:
                break;
            case 1:
                console.log(ponto.getX());
                break;
            case 2:
                console.log(ponto.getY());
                break;
            case 3:
                ponto.setX(rl.questionInt('x: '));
                break;
            case 4:
                ponto.setY(rl.questionInt('y: '));
                break;
            case 5:
                tmp = new Ponto2D_1.Ponto2D(rl.questionInt('Valor de x do outro ponto: '), rl.questionInt('Valor de y do outro ponto: '));
                console.log("S\u00E3o iguais? ".concat(ponto.equals(tmp)));
                break;
            case 6:
                tmp = new Ponto2D_1.Ponto2D(rl.questionInt('Valor de x do outro ponto: '), rl.questionInt('Valor de y do outro ponto: '));
                console.log("Dist\u00E2ncia: ".concat(ponto.distancia(tmp)));
                break;
            case 7:
                tmp = ponto.clone();
                console.log("Ponto clonado: ".concat(tmp.toString()));
                break;
            case 8:
                console.log("Ponto atual: ".concat(ponto.toString()));
                break;
            default:
                console.log('Opção inválida. Tente novamente.');
                break;
        }
        rl.question("Pressione Enter para continuar...");
    }
}
exports.ponto2DMenu = ponto2DMenu;
