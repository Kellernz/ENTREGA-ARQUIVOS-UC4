"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.numeroComplexoMenu = void 0;
var rl = require("readline-sync");
var NumeroComplexo_1 = require("../NumeroComplexo");
function numeroComplexoMenu() {
    var numero = new NumeroComplexo_1.NumeroComplexo();
    var temporario = new NumeroComplexo_1.NumeroComplexo();
    var opt = -1;
    while (opt !== 0) {
        console.clear();
        console.log('Menu Numero Complexo');
        console.log('0. Sair');
        console.log('1. Mostrar número real');
        console.log('2. Mostrar número imaginário');
        console.log('3. Definir número real');
        console.log('4. Definir número imaginário');
        console.log('5. Adição com outro número');
        console.log('6. Subtração com outro número');
        console.log('7. Multiplicação com outro número');
        console.log('8. Divisão com outro número');
        console.log('9. Mostrar módulo');
        console.log('10. Comparar com outro número');
        console.log("Valor atual do n\u00FAmero: ".concat(numero.toString()));
        opt = rl.questionInt("Escolha uma opção: ");
        switch (opt) {
            case 0:
                break;
            case 1:
                console.log("N\u00FAmero real: ".concat(numero.getReal()));
                break;
            case 2:
                console.log("N\u00FAmero imagin\u00E1rio: ".concat(numero.getImaginario()));
                break;
            case 3:
                numero.setReal(rl.questionInt("Novo valor real: "));
                break;
            case 4:
                numero.setImaginario(rl.questionInt("Novo valor imaginário: "));
                break;
            case 5:
                temporario = new NumeroComplexo_1.NumeroComplexo(rl.questionInt("Valor real do outro número: "), rl.questionInt("Valor imaginário do outro número: "));
                console.log("Resultado da adi\u00E7\u00E3o: ".concat(numero.somar(temporario).toString()));
                break;
            case 6:
                temporario = new NumeroComplexo_1.NumeroComplexo(rl.questionInt("Valor real do outro número: "), rl.questionInt("Valor imaginário do outro número: "));
                console.log("Resultado da subtra\u00E7\u00E3o: ".concat(numero.subtrair(temporario).toString()));
                break;
            case 7:
                temporario = new NumeroComplexo_1.NumeroComplexo(rl.questionInt("Valor real do outro número: "), rl.questionInt("Valor imaginário do outro número: "));
                console.log("Resultado da multiplica\u00E7\u00E3o: ".concat(numero.multiplicar(temporario).toString()));
                break;
            case 8:
                temporario = new NumeroComplexo_1.NumeroComplexo(rl.questionInt("Valor real do outro número: "), rl.questionInt("Valor imaginário do outro número: "));
                console.log("Resultado da divis\u00E3o: ".concat(numero.dividir(temporario).toString()));
                break;
            case 9:
                console.log("M\u00F3dulo: ".concat(numero.modulo()));
                break;
            case 10:
                temporario = new NumeroComplexo_1.NumeroComplexo(rl.questionInt("Valor real do outro número: "), rl.questionInt("Valor imaginário do outro número: "));
                console.log("S\u00E3o iguais? ".concat(numero.equals(temporario)));
                break;
            default:
                console.log('Opção inválida. Tente novamente.');
        }
        rl.question("Pressione Enter para continuar...");
    }
}
exports.numeroComplexoMenu = numeroComplexoMenu;
