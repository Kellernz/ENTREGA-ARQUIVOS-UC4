import * as rl from 'readline-sync';
import { NumeroComplexo } from '../NumeroComplexo';

export function numeroComplexoMenu(): void {
    let numero = new NumeroComplexo();
    let temporario = new NumeroComplexo();
    let opt: number = -1;

    while (opt !== 0) {
        console.clear();

        console.log('Menu Numero Complexo');
        console.log('0. Sair');
        console.log('1. Mostrar número real');
        console.log('2. Mostrar número imaginário');
        console.log('3. Definir número real');
        console.log('4. Definir número imaginário');
        console.log('5. Adição com outro número');
        console.log('6. Subtração com outro número');
        console.log('7. Multiplicação com outro número');
        console.log('8. Divisão com outro número');
        console.log('9. Mostrar módulo');
        console.log('10. Comparar com outro número');
        
        console.log(`Valor atual do número: ${numero.toString()}`);

        opt = rl.questionInt("Escolha uma opção: ");

        switch (opt) {
            case 0:
                break;
            case 1:
                console.log(`Número real: ${numero.getReal()}`);
                break;
            case 2:
                console.log(`Número imaginário: ${numero.getImaginario()}`);
                break;
            case 3:
                numero.setReal(rl.questionInt("Novo valor real: "));
                break;
            case 4:
                numero.setImaginario(rl.questionInt("Novo valor imaginário: "));
                break;
            case 5:
                temporario = new NumeroComplexo(
                    rl.questionInt("Valor real do outro número: "), 
                    rl.questionInt("Valor imaginário do outro número: ")
                );
                console.log(`Resultado da adição: ${numero.somar(temporario).toString()}`);
                break;
            case 6:
                temporario = new NumeroComplexo(
                    rl.questionInt("Valor real do outro número: "), 
                    rl.questionInt("Valor imaginário do outro número: ")
                );
                console.log(`Resultado da subtração: ${numero.subtrair(temporario).toString()}`);
                break;
            case 7:
                temporario = new NumeroComplexo(
                    rl.questionInt("Valor real do outro número: "), 
                    rl.questionInt("Valor imaginário do outro número: ")
                );
                console.log(`Resultado da multiplicação: ${numero.multiplicar(temporario).toString()}`);
                break;
            case 8:
                temporario = new NumeroComplexo(
                    rl.questionInt("Valor real do outro número: "), 
                    rl.questionInt("Valor imaginário do outro número: ")
                );
                console.log(`Resultado da divisão: ${numero.dividir(temporario).toString()}`);
                break;
            case 9:
                console.log(`Módulo: ${numero.modulo()}`);
                break;
            case 10:
                temporario = new NumeroComplexo(
                    rl.questionInt("Valor real do outro número: "), 
                    rl.questionInt("Valor imaginário do outro número: ")
                );
                console.log(`São iguais? ${numero.equals(temporario)}`);
                break;
            default:
                console.log('Opção inválida. Tente novamente.');
        }

        rl.question("Pressione Enter para continuar...");
    }
}
