import * as rl from 'readline-sync';
import { Ponto2D } from '../Ponto2D';

export function ponto2DMenu(): void {
    let ponto = new Ponto2D();
    let tmp = new Ponto2D();
    let opt: number = -1;

    while (opt !== 0) {
        console.clear();

        console.log('Menu Ponto 2D');
        console.log('0. Sair');
        console.log('1. Mostrar x');
        console.log('2. Mostrar y');
        console.log('3. Definir x');
        console.log('4. Definir y');
        console.log('5. Comparar com outro');
        console.log('6. Mostrar distância para outro');
        console.log('7. Clonar ponto');
        console.log('8. Mostrar valor');

        opt = rl.questionInt("Escolha uma opção: ");

        switch (opt) {
            case 0:
                break;
            case 1:
                console.log(ponto.getX());
                break;
            case 2:
                console.log(ponto.getY());
                break;
            case 3:
                ponto.setX(rl.questionInt('x: '));
                break;
            case 4:
                ponto.setY(rl.questionInt('y: '));
                break;
            case 5: 
                tmp = new Ponto2D(
                    rl.questionInt('Valor de x do outro ponto: '),
                    rl.questionInt('Valor de y do outro ponto: ')
                );
                console.log(`São iguais? ${ponto.equals(tmp)}`);
                break;
            case 6: 
                tmp = new Ponto2D(
                    rl.questionInt('Valor de x do outro ponto: '),
                    rl.questionInt('Valor de y do outro ponto: ')
                );
                console.log(`Distância: ${ponto.distancia(tmp)}`);
                break;
            case 7:
                tmp = ponto.clone();
                console.log(`Ponto clonado: ${tmp.toString()}`);
                break;
            case 8:
                console.log(`Ponto atual: ${ponto.toString()}`);
                break;
            default:
                console.log('Opção inválida. Tente novamente.');
		break;
        }

        rl.question("Pressione Enter para continuar...");
    }
}
