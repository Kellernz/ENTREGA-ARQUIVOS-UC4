"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NumeroComplexo = void 0;
var NumeroComplexo = /** @class */ (function () {
    function NumeroComplexo(real, imaginario) {
        if (real === void 0) { real = 0; }
        if (imaginario === void 0) { imaginario = 0; }
        this.real = real;
        this.imaginario = imaginario;
    }
    NumeroComplexo.prototype.getReal = function () {
        return this.real;
    };
    NumeroComplexo.prototype.getImaginario = function () {
        return this.imaginario;
    };
    NumeroComplexo.prototype.setReal = function (real) {
        this.real = real;
    };
    NumeroComplexo.prototype.setImaginario = function (imaginario) {
        this.imaginario = imaginario;
    };
    NumeroComplexo.prototype.somar = function (outro) {
        return new NumeroComplexo(this.real + outro.getReal(), this.imaginario + outro.getImaginario());
    };
    NumeroComplexo.prototype.subtrair = function (outro) {
        return new NumeroComplexo(this.real - outro.getReal(), this.imaginario - outro.getImaginario());
    };
    NumeroComplexo.prototype.multiplicar = function (outro) {
        return new NumeroComplexo(this.real * outro.getReal() - this.imaginario * outro.getImaginario(), this.real * outro.getImaginario() + this.imaginario * outro.getReal());
    };
    NumeroComplexo.prototype.dividir = function (outro) {
        var denominador = (outro.getReal() * outro.getReal()) + (outro.getImaginario() * outro.getImaginario());
        return new NumeroComplexo((this.real * outro.getReal() + this.imaginario * outro.getImaginario()) / denominador, (this.imaginario * outro.getReal() - this.real * outro.getImaginario()) / denominador);
    };
    NumeroComplexo.prototype.equals = function (outro) {
        return this.real === outro.getReal() && this.imaginario === outro.getImaginario();
    };
    NumeroComplexo.prototype.toString = function () { return "".concat(this.real, " + ").concat(this.imaginario, "i"); };
    NumeroComplexo.prototype.modulo = function () {
        return Math.sqrt((this.real * this.real) + (this.imaginario * this.imaginario));
    };
    return NumeroComplexo;
}());
exports.NumeroComplexo = NumeroComplexo;
