export class NumeroComplexo {
    private real: number;
    private imaginario: number;

    constructor(real: number = 0, imaginario: number = 0) {
        this.real = real;
        this.imaginario = imaginario;
    }

    getReal(): number {
        return this.real;
    }
    
    getImaginario(): number {
        return this.imaginario;
    }

    setReal(real: number): void {
        this.real = real;
    }
    
    setImaginario(imaginario: number): void {
        this.imaginario = imaginario;
    }

    somar(outro: NumeroComplexo): NumeroComplexo {
        return new NumeroComplexo(this.real + outro.getReal(), this.imaginario + outro.getImaginario());
    }

    subtrair(outro: NumeroComplexo): NumeroComplexo {
        return new NumeroComplexo(this.real - outro.getReal(), this.imaginario - outro.getImaginario());
    }

    multiplicar(outro: NumeroComplexo): NumeroComplexo {
        return new NumeroComplexo(
            this.real * outro.getReal() - this.imaginario * outro.getImaginario(),
            this.real * outro.getImaginario() + this.imaginario * outro.getReal()
        );
    }

    dividir(outro: NumeroComplexo): NumeroComplexo {
        const denominador = (outro.getReal() * outro.getReal()) + (outro.getImaginario() * outro.getImaginario());

        return new NumeroComplexo(
            (this.real      * outro.getReal() + this.imaginario * outro.getImaginario()) / denominador,
            (this.imaginario * outro.getReal() - this.real      * outro.getImaginario()) / denominador
        );
    }

    equals(outro: NumeroComplexo): boolean {
        return this.real === outro.getReal() && this.imaginario === outro.getImaginario();
    }
    
    toString(): String { return `${this.real} + ${this.imaginario}i`; }

    modulo(): number {
        return Math.sqrt(
            (this.real * this.real) + (this.imaginario * this.imaginario)
        );
    }
}

