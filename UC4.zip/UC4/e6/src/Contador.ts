export class Contador {
    private value: number;
    constructor() {
        this.zerar();
    }

    public zerar(): void {
        this.value = 0;
    }

    public incrementar(): void {
        this.value++;
    }

    public valor(): number {
        return this.value;
    }
}

