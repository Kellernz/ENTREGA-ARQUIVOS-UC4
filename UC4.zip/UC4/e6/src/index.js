"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rl = require("readline-sync");
var Contador_1 = require("./menu/Contador");
var Ponto2D_1 = require("./menu/Ponto2D");
var NumeroComplexo_1 = require("./menu/NumeroComplexo");
function menu() {
    console.clear();
    var opt = -1;
    while (opt != 0) {
        console.log('Menu');
        console.log('0. Sair');
        console.log('1. Contador');
        console.log('2. Ponto 2D');
        console.log('3. Numero Complexo');
        opt = Number(rl.questionInt('Digite uma das opções acima: '));
        switch (opt) {
            case 0:
                break;
            case 1:
                (0, Contador_1.contadorMenu)();
                break;
            case 2:
                (0, Ponto2D_1.ponto2DMenu)();
                break;
            case 3:
                (0, NumeroComplexo_1.numeroComplexoMenu)();
                break;
            default:
                console.log('Digite uma opção válida');
                rl.question('Pressione Enter para prosseguir...');
                break;
        }
    }
    console.clear();
}
menu();
