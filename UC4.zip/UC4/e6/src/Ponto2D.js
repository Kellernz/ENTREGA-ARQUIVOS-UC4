"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Ponto2DFromPonto2D = exports.Ponto2D = void 0;
var Ponto2D = /** @class */ (function () {
    function Ponto2D(x, y) {
        if (x === void 0) { x = 0; }
        if (y === void 0) { y = 0; }
        this.x = x;
        this.y = y;
    }
    Ponto2D.prototype.getX = function () {
        return this.x;
    };
    Ponto2D.prototype.getY = function () {
        return this.y;
    };
    Ponto2D.prototype.setX = function (x) {
        this.x = x;
    };
    Ponto2D.prototype.setY = function (y) {
        this.y = y;
    };
    Ponto2D.prototype.move = function (x, y) {
        this.x = x;
        this.y = y;
    };
    Ponto2D.prototype.equals = function (outro) {
        return this.getX() === outro.getX() && this.getY() === outro.getY();
    };
    Ponto2D.prototype.toString = function () {
        return "Ponto2D { x = ".concat(this.x, ", y = ").concat(this.y, " }");
    };
    Ponto2D.prototype.distancia = function (outro) {
        return Math.abs(this.x - outro.getX()) + Math.abs(this.y - outro.getY());
    };
    Ponto2D.prototype.clone = function () {
        return new Ponto2D(this.x, this.y);
    };
    return Ponto2D;
}());
exports.Ponto2D = Ponto2D;
var Ponto2DFromPonto2D = /** @class */ (function (_super) {
    __extends(Ponto2DFromPonto2D, _super);
    function Ponto2DFromPonto2D(ponto) {
        return _super.call(this, ponto.getX(), ponto.getY()) || this;
    }
    return Ponto2DFromPonto2D;
}(Ponto2D));
exports.Ponto2DFromPonto2D = Ponto2DFromPonto2D;
