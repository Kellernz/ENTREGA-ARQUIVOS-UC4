"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Contador = void 0;
var Contador = /** @class */ (function () {
    function Contador() {
        this.zerar();
    }
    Contador.prototype.zerar = function () {
        this.value = 0;
    };
    Contador.prototype.incrementar = function () {
        this.value++;
    };
    Contador.prototype.valor = function () {
        return this.value;
    };
    return Contador;
}());
exports.Contador = Contador;
