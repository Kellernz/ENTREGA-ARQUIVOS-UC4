export class Ponto2D {
    public x: number;
    public y: number;

    constructor(x: number = 0, y: number = 0) {
        this.x = x;
        this.y = y;
    }

    public getX(): number {
        return this.x;
    }

    public getY(): number {
        return this.y;
    }

    public setX(x: number): void {
        this.x = x;
    }
    
    public setY(y: number): void {
        this.y = y;
    }

    move(x: number, y: number): void {
        this.x = x;
        this.y = y;
    }
    
    equals(outro: Ponto2D): boolean {
        return this.getX() === outro.getX() && this.getY() === outro.getY();
    }

    toString(): string {
        return `Ponto2D { x = ${this.x}, y = ${this.y} }`;    
    }

    distancia(outro: Ponto2D): number {
        return Math.abs(this.x - outro.getX()) + Math.abs(this.y - outro.getY());
    }

    clone(): Ponto2D {
        return new Ponto2D(this.x, this.y);
    }
}

export class Ponto2DFromPonto2D extends Ponto2D {
    constructor(ponto: Ponto2D) {
        super(ponto.getX(), ponto.getY());
    }
}

