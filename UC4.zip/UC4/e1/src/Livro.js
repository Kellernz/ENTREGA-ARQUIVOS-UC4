var Livro = /** @class */ (function () {
    function Livro(titulo, autor, anoPublicacao) {
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicacao = anoPublicacao;
    }
    Livro.prototype.obterDetalhes = function () {
        return "".concat(this.titulo, " de ").concat(this.autor, ", lan\u00E7ado em ").concat(this.anoPublicacao);
    };
    return Livro;
}());
var livro = new Livro("O Capital", "Karl Marx", 1867);
console.log(livro.obterDetalhes());
