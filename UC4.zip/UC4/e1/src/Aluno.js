var Aluno = /** @class */ (function () {
    function Aluno(nome, notas) {
        this.nome = nome;
        this.notas = notas;
    }
    Aluno.prototype.addNota = function (nota) {
        this.notas.push(nota);
    };
    Aluno.prototype.media = function () {
        var soma = 0;
        for (var _i = 0, _a = this.notas; _i < _a.length; _i++) {
            var nota = _a[_i];
            soma += nota;
        }
        return soma / this.notas.length;
    };
    return Aluno;
}());
;
var aluno = new Aluno("Guilherme", new Array(6, 8));
aluno.addNota(7);
aluno.addNota(8);
aluno.addNota(4);
console.log(aluno.media());
