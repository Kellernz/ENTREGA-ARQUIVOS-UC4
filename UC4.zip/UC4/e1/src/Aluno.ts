class Aluno {
    nome: string;
    notas: number[];

    constructor(nome: string, notas: number[]) {
        this.nome = nome;
        this.notas = notas;
    }

    addNota(nota: number): void {
        this.notas.push(nota)
    }

    media(): number {
        let soma = 0;
        for (const nota of this.notas) {
            soma += nota;
        }
        
        return soma / this.notas.length;
    }
};

let aluno = new Aluno("Guilherme", new Array<number>(6, 8));

aluno.addNota(7);
aluno.addNota(8);
aluno.addNota(4);

console.log(aluno.media());
