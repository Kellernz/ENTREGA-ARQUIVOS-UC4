class Pessoa {
    nome: string;
    idade: number;

    constructor(nome: string, idade: number) {
        this.nome = nome;
        this.idade = idade;
    }

    cumprimentar(): void {
        console.log(`Olá meu nome é ${this.nome}.`);
    }
}

class Crianca extends Pessoa {
    cumprimentar(): void {
        console.log(`Oi meu nome é ${this.nome} e eu tenho ${this.idade} anos!`);
    }
}

class Adulto extends Pessoa {
    cumprimentar(): void {
        console.log(`Olá meu nome é ${this.nome} e eu tenho ${this.idade} anos.`);
    }
}

class Idoso extends Pessoa {
    cumprimentar(): void {
        console.log(`Bença eu sou ${this.nome} e tenho ${this.idade} anos.`);
    }
}

let pessoa = new Pessoa("Karl Marx", 200);

let crianca = new Crianca("Enzo", 7);
let adulto = new Adulto("Cleber", 34);
let idoso = new Idoso("Urbano Silva", 77);

pessoa.cumprimentar()
crianca.cumprimentar();
adulto.cumprimentar();
idoso.cumprimentar();

