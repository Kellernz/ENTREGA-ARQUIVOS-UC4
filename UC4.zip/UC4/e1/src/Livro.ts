class Livro {
    titulo: string;
    autor: string;
    anoPublicacao: number;

    constructor(titulo: string, autor: string, anoPublicacao: number) {
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicacao = anoPublicacao;
    }

    obterDetalhes(): string {
        return `${this.titulo} de ${this.autor}, lançado em ${this.anoPublicacao}`;
    }
}

let livro = new Livro("O Capital", "Karl Marx", 1867);
console.log(livro.obterDetalhes());
