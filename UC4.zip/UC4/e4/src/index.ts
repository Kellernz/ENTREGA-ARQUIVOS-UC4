import * as rl from 'readline-sync';

import { Game, EletronicGame, BoardGame } from './game';
import { GameLibrary } from './GameLibrary';

let library = new GameLibrary();
let option: number = 0;

do {
    console.log('0. Terminar');
    console.log('1. adicionar jogo.');
    console.log('2. Remover jogo.');
    console.log('3. Listar biblioteca.');

    option = rl.questionInt('Escolha uma das opcoes acima:');

    switch (option) {
        case 0:
            break;
        case 1:
            if (rl.question("Tipo de jogo? (t para tabuleiro, e para eletronico)").toLowerCase() === "t") {
                library.pushGame(new EletronicGame(
                    rl.question("Titulo:"),
                    rl.question("Genero: "),
                    rl.questionInt("Faixa etária: "),
                    rl.question("Plataforma: ")
                ));    
            } else {
                library.pushGame(new BoardGame(
                    rl.question("Titulo:"),
                    rl.question("Genero: "),
                    rl.questionInt("Faixa etária: "),
                    rl.questionInt("Número de jogadores:")
                ));
            }
            break;
        case 2:
            library.deleteGame(rl.question("Titulo: "));
            break;
        case 3:
            library.listGames();
        default:
            console.log('Erro de opção inválida');
            break;
    }

} while (option !== 0);

