"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.BoardGame = exports.EletronicGame = exports.Game = void 0;
var Game = /** @class */ (function () {
    function Game(title, genre, rating) {
        this.title = title;
        this.genre = genre;
        this.rating = rating;
    }
    Game.prototype.getDetails = function () {
        try {
            return "T\u00EDtulo: ".concat(this.title, "\nG\u00EAnero: ").concat(this.genre, "\nFaixa et\u00E1ria: ").concat(this.rating);
        }
        catch (error) {
            console.log("get details error: ".concat(error));
        }
        return '';
    };
    Game.prototype.getTitle = function () {
        try {
            return this.title;
        }
        catch (error) {
            console.log("get title error: ".concat(error));
        }
        return '';
    };
    Game.prototype.getGenre = function () {
        try {
            return this.genre;
        }
        catch (error) {
            console.log("get genre error: ".concat(error));
        }
        return '';
    };
    Game.prototype.getRating = function () {
        try {
            return this.rating;
        }
        catch (error) {
            console.log("get minimum age error: ".concat(error));
        }
        return -1;
    };
    return Game;
}());
exports.Game = Game;
;
var EletronicGame = /** @class */ (function (_super) {
    __extends(EletronicGame, _super);
    function EletronicGame(title, genre, rating, plataform) {
        var _this = _super.call(this, title, genre, rating) || this;
        _this.plataform = plataform;
        return _this;
    }
    EletronicGame.prototype.getDetails = function () {
        try {
            return "T\u00EDtulo: ".concat(this.getTitle(), "\nG\u00EAnero: ").concat(this.getGenre(), "\nFaixa et\u00E1ria: ").concat(this.getRating(), "\nPlataforma: ").concat(this.plataform);
        }
        catch (error) {
            console.log("get details error: ".concat(error));
        }
    };
    EletronicGame.prototype.getPlataform = function () {
        try {
            return this.plataform;
        }
        catch (error) {
            console.log("get plataform error: ".concat(error));
        }
        return '';
    };
    return EletronicGame;
}(Game));
exports.EletronicGame = EletronicGame;
;
var BoardGame = /** @class */ (function (_super) {
    __extends(BoardGame, _super);
    function BoardGame(title, genre, rating, playerNumber) {
        var _this = _super.call(this, title, genre, rating) || this;
        _this.playerNumber = playerNumber;
        return _this;
    }
    BoardGame.prototype.getDetails = function () {
        try {
            return "T\u00EDtulo: ".concat(this.getTitle(), "\nG\u00EAnero: ").concat(this.getGenre(), "\nFaixa et\u00E1ria: ").concat(this.getRating(), "\nN\u00FAmero de jogadores: ").concat(this.playerNumber);
        }
        catch (error) {
            console.log("get details error: ".concat(error));
        }
    };
    BoardGame.prototype.getPlayerNumber = function () {
        try {
            return this.playerNumber;
        }
        catch (error) {
            console.log("get player number error: ".concat(error));
        }
        return -1;
    };
    return BoardGame;
}(Game));
exports.BoardGame = BoardGame;
;
