"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameLibrary = void 0;
var GameLibrary = /** @class */ (function () {
    function GameLibrary() {
        this.games = [];
    }
    GameLibrary.prototype.pushGame = function (game) {
        try {
            this.games.push(game);
        }
        catch (error) {
            console.log("push game error: ".concat(error));
        }
    };
    GameLibrary.prototype.deleteGame = function (title) {
        try {
            for (var i = 0; i < this.games.length; ++i) {
                if (this.games[i].getTitle() === title) {
                    this.games.splice(i, 1);
                    return;
                }
            }
            throw new Error("No game named ".concat(title));
        }
        catch (error) {
            console.log("delete game error: ".concat(error));
        }
    };
    GameLibrary.prototype.listGames = function () {
        var result = '';
        try {
            for (var i = 0; i < this.games.length; ++i)
                result += this.games[i].getDetails() + '\n';
        }
        catch (error) {
            console.log("error listing games: ".concat(error));
        }
        return result;
    };
    return GameLibrary;
}());
exports.GameLibrary = GameLibrary;
;
