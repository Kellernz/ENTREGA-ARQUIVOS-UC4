export class Game {
    constructor(private title: string, private genre: string, private rating: number) {}
    getDetails(): string
    {
        try {
            return `Título: ${this.title}\nGênero: ${this.genre}\nFaixa etária: ${this.rating}`;
        } catch (error) {
            console.log(`get details error: ${error}`);
        }

        return '';
    }

    getTitle(): string
    {
        try {
            return this.title;
        } catch(error) {
            console.log(`get title error: ${error}`);
        }

        return '';
    }

    getGenre(): string
    {
        try {
            return this.genre;
        } catch(error) {
            console.log(`get genre error: ${error}`);
        }

        return '';
    }

    getRating(): number
    {
        try {
            return this.rating;
        } catch(error) {
            console.log(`get minimum age error: ${error}`);
        }
        
        return -1;
    }
};

export class EletronicGame extends Game {
    constructor(
        title: string,
        genre: string,
        rating: number,
        private plataform: string) { super(title, genre, rating); }
    
    getDetails(): string
    {
        try {
            return `Título: ${this.getTitle()}\nGênero: ${this.getGenre()}\nFaixa etária: ${this.getRating()}\nPlataforma: ${this.plataform}`;
        } catch (error) {
            console.log(`get details error: ${error}`);
        }
    }

    getPlataform(): string
    {
        try {
            return this.plataform;
        } catch(error) {
            console.log(`get plataform error: ${error}`);
        }

        return '';
    }

};

export class BoardGame extends Game {
    constructor(
        title: string,
        genre: string,
        rating: number,
        private playerNumber: number) { super(title, genre, rating); }
    
    getDetails(): string
    {
        try {
            return `Título: ${this.getTitle()}\nGênero: ${this.getGenre()}\nFaixa etária: ${this.getRating()}\nNúmero de jogadores: ${this.playerNumber}`;
        } catch (error) {
            console.log(`get details error: ${error}`);
        }
    }

    getPlayerNumber(): number
    {
        try {
            return this.playerNumber;
        } catch(error) {
            console.log(`get player number error: ${error}`);
        }

        return -1;
    }

};
