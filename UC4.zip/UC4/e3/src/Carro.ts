export class Carro {
    modelo: string;
    kmPorLitro: number;
    gasolina: number;
    tanque: number;

    constructor(modelo: string, kmPorLitro: number, gasolina: number, tanque: number) {
        this.modelo = modelo;
        this.kmPorLitro = kmPorLitro;
        this.gasolina = gasolina;
        this.tanque = tanque;
    }

    dirigir(distancia: number): void {
        let gasto = distancia * this.kmPorLitro;
        if (gasto > this.gasolina) {
            console.log(`Precisa de mais gasolina`);
            return;
        }

        this.gasolina -= gasto;
    }

    getModelo(): string {
        return this.modelo
    }

    getGasolina(): number {
        return this.gasolina;
    }

    getTanque(): number {
        return this.tanque;
    }

    porGasolina(litros: number): void {
        if (this.gasolina + litros > this.tanque) {
            console.log("Muita gasosa");
            return;
        }

        this.gasolina += litros;
    }    
}

