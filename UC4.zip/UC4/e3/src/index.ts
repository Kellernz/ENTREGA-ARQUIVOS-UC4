import * as rl from 'readline-sync';
import { Carro } from './Carro';

const garagem: Carro[] = [
    new Carro('Kwid', 12, 32, 50),
];

// Mostra a garagem
function mostrarGaragem(): void {
    console.log('Garagem:');
    for (let i = 0; i < garagem.length; ++i) {
        const carro = garagem[i];
        console.log(`${i + 1}: ${carro.getModelo()}`);
    }
}

// Escolhe um carro da garagem
function escolherCarro(): Carro {
    let i: number = 0;
    mostrarGaragem();

    while (i <= 0 || i > garagem.length) {
        i = rl.questionInt("Digite a posição do carro: ");
    }
    return garagem[i - 1];
}

let opcao: string = '';
let carroSelecionado = escolherCarro();

console.clear();

while (opcao != '0') {
    console.log(`0. Sair
1. Exibir gasolina
2. Exibir garagem
3. Adicionar carro
4. Remover carro
5. Selecionar carro
6. Dirigir o carro
7. Adicionar mais gasosa`);

    opcao = rl.question("Escolha uma opção do menu: ");
    switch (opcao) {
	case '0':
	    break;
        case '1':
            console.log(`Gasolina: ${carroSelecionado.getGasolina()} L`);
            break;
        case '2':
            mostrarGaragem();
            break;
        case '3':
            if (garagem.length >= 10) {
                console.log("Garagem cheia.");
                break;
            }
            garagem.push(new Carro(
                rl.question("Modelo: "),
                rl.questionInt("Eficiência (km/L): "),
                rl.questionInt("Gasolina no tanque: "),
                rl.questionInt("Capacidade máxima do tanque: ")
            ));
            break;
        case '4':
            const modeloParaRemover = rl.question("Carro para remover: ");
            const indexParaRemover = garagem.findIndex(carro => carro.getModelo() === modeloParaRemover);
            if (indexParaRemover !== -1) {
                garagem.splice(indexParaRemover, 1);
            } else {
                console.log("Carro não encontrado.");
            }
            break;
        case '5':
            carroSelecionado = escolherCarro();
            break;
        case '6':
            carroSelecionado.dirigir(rl.questionInt("Distância (km): "));
            break;
        case '7':
            carroSelecionado.porGasolina(rl.questionInt("Quantidade de gasolina (L): "));
            break;
        default:
            console.log("Opção inválida.");
            break;
    }

    rl.question("Pressione ENTER para continuar.");
    console.clear();
}
