"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Carro = void 0;
var Carro = /** @class */ (function () {
    function Carro(modelo, kmPorLitro, gasolina, tanque) {
        this.modelo = modelo;
        this.kmPorLitro = kmPorLitro;
        this.gasolina = gasolina;
        this.tanque = tanque;
    }
    Carro.prototype.dirigir = function (distancia) {
        var gasto = distancia * this.kmPorLitro;
        if (gasto > this.gasolina) {
            console.log("Precisa de mais gasolina");
            return;
        }
        this.gasolina -= gasto;
    };
    Carro.prototype.getModelo = function () {
        return this.modelo;
    };
    Carro.prototype.getGasolina = function () {
        return this.gasolina;
    };
    Carro.prototype.getTanque = function () {
        return this.tanque;
    };
    Carro.prototype.porGasolina = function (litros) {
        if (this.gasolina + litros > this.tanque) {
            console.log("Muita gasosa");
            return;
        }
        this.gasolina += litros;
    };
    return Carro;
}());
exports.Carro = Carro;
