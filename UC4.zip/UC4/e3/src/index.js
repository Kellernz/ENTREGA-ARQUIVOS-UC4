"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rl = require("readline-sync");
var Carro_1 = require("./Carro");
var garagem = [
    new Carro_1.Carro('Kwid', 12, 32, 50),
];
// Mostra a garagem
function mostrarGaragem() {
    console.log('Garagem:');
    for (var i = 0; i < garagem.length; ++i) {
        var carro = garagem[i];
        console.log("".concat(i + 1, ": ").concat(carro.getModelo()));
    }
}
// Escolhe um carro da garagem
function escolherCarro() {
    var i = 0;
    mostrarGaragem();
    while (i <= 0 || i > garagem.length) {
        i = rl.questionInt("Digite a posição do carro: ");
    }
    return garagem[i - 1];
}
var opcao = '';
var carroSelecionado = escolherCarro();
console.clear();
var _loop_1 = function () {
    console.log("0. Sair\n1. Exibir gasolina\n2. Exibir garagem\n3. Adicionar carro\n4. Remover carro\n5. Selecionar carro\n6. Dirigir o carro\n7. Adicionar mais gasosa");
    opcao = rl.question("Escolha uma opção do menu: ");
    switch (opcao) {
        case '1':
            console.log("Gasolina: ".concat(carroSelecionado.getGasolina(), " L"));
            break;
        case '2':
            mostrarGaragem();
            break;
        case '3':
            if (garagem.length >= 10) {
                console.log("Garagem cheia.");
                break;
            }
            garagem.push(new Carro_1.Carro(rl.question("Modelo: "), rl.questionInt("Eficiência (km/L): "), rl.questionInt("Gasolina no tanque: "), rl.questionInt("Capacidade máxima do tanque: ")));
            break;
        case '4':
            var modeloParaRemover_1 = rl.question("Carro para remover: ");
            var indexParaRemover = garagem.findIndex(function (carro) { return carro.getModelo() === modeloParaRemover_1; });
            if (indexParaRemover !== -1) {
                garagem.splice(indexParaRemover, 1);
            }
            else {
                console.log("Carro não encontrado.");
            }
            break;
        case '5':
            carroSelecionado = escolherCarro();
            break;
        case '6':
            carroSelecionado.dirigir(rl.questionInt("Distância (km): "));
            break;
        case '7':
            carroSelecionado.porGasolina(rl.questionInt("Quantidade de gasolina (L): "));
            break;
        default:
            console.log("Opção inválida.");
            break;
    }
    rl.question("Pressione ENTER para continuar.");
    console.clear();
};
while (opcao != '0') {
    _loop_1();
}
