import * as rl from 'readline-sync';

class Produto {
    nome: string;
    marca: string;
    custo: number;
    preco: number;
    estoque: number;

    constructor(nome: string, marca: string, custo: number, preco: number, estoque: number) {
        this.nome = nome;
        this.marca = marca;
        this.custo = custo;
        this.preco = preco;
        this.estoque = estoque;
    }

    setProduto(): void {
        this.nome = rl.question("Nome do produto: ");
        this.marca = rl.question("Marca do produto:");
        this.custo = rl.questionInt("Custo do produto: ");
        this.preco = rl.questionInt("Preço de venda do produto: ");
        this.estoque = rl.questionInt("Estoque do produto: ");
    }

    getLucro(): number {
        return this.preco - this.custo;
    }
};

class Venda {
    produto: Produto;
    quantidade: number;
    data: string;

    constructor(produto: Produto, quantidade: number, data: string) {
        this.produto = produto;
        this.quantidade = quantidade;
        this.data = data;
    }
    
    getVenda(): string {
        return `${this.produto.nome} - ${this.quantidade} Custo R$ ${this.getCustoTotal()}`;
    }

    setVenda(): void {
        if (rl.question("Você gostaria de modificar o produto? (s/n)").toLowerCase() === "s") {
            this.produto.setProduto();
        }

        this.quantidade = rl.questionInt("Quantidade do produto: ");
        this.data = rl.question("Data da venda: ");
    }

    getCustoTotal(): number {
        return (this.produto.preco * this.quantidade);
    }
};


let produto = new Produto("", "", 0, 0, 0);
let venda = new Venda(produto, 1, "2024-02-07");

produto.setProduto();

while (rl.question(venda.getVenda() + "\nAlterar a venda? (s/n)").toLowerCase() === "s") {
    venda.setVenda();
}

console.log(venda.getVenda());
